#include <stdio.h>
#include <arm.h>

main()
{
   struct REGS in,out;
   
   in.R0=153;
   in.R1=0;
   in.R2='F';
   
   /* mette la F nel buffer di tastiera */
   
   swi(6,&in,&out);
   printf("R0 vale %d, R1 %d, R2 %d\n",out.R0,out.R1,out.R2);
   }
  
