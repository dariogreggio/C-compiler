short b;
long l;

interrupt void pippo() {
//	b=1;  
	b++;
	l=b+4;
	}

short culetto[5];
int main(int argc, char **argv) {
	short /*int*/ i;
	register char ch,*p1;
	char *p;
	int *ip;

	ch=culetto[2];
*(p + 3)='G';
	culetto[2]=ch;
	i=*p;
	ch=*p;
ch=*p1;
#if 0
	i=*argv;
	i=(*p)+9;
	i=*(p+7);
	*p=ch;
	i=i+i;
ip=ip+3;
	b = l>>ch;
	b=b << ch;
	b=b << i;
	b=b << 2;
	b = l>>4;
	b=7+i;
	b=ch+ch;
//	i=i*ch;
	culo();
	ch= ch + 3;
	ch= ch + i;
	ch= ch * i;
//ch++;
//b--;
//	*p1=11;
	ch= ch << 3;



//	b= i || 9;
	b= i || b;
	i=i & i;
	i=i << i;
	i=i << ch;
	i=i * i;

#ifdef MC6800
	b=i || i;
	b=ch && 1;
	b=ch && 0;
	if(b && 1)
		goto piciu;
	if(b || 1)
		goto piciu;
	if(b || i)
		goto piciu;
	if(b==1 && i==45)
		goto piciu;
	if(b && 0)
		goto piciu;
	if(b && i)
		goto piciu;
	if(i || b)
		goto piciu;
	if(i && ch)
		goto piciu;

	b=9;
	l-=i;
	i+=9;
	l=l+3;
	i=i+i;
	l=l*2;
	i=i*7;
	b=b + *p;
	b= *p + 1;
	b=b / *p;
	l=l / 2;
	b=b/5;
	b=b % 5;
	b= i/ch;
#if 1
	b |= 2;
#endif
	b = b | 3;
	b= b ^ 4;
	b= b ^ ch;
	b= b < ch;
	ch= b ^ ch;
#else
	culo();
#if defined(MC68000)
//	b |= 0x92;
#endif
#endif
	ch= ch > 3;
	ch='A';
	ch=*p;
	*p=1;
	ch=*p1;
	*p1=11;

	b= ch > 3;
#endif
	}

