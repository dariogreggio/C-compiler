int a;

main()
{         /* Questo programma non deve girare */
   int t,i;
   char *q;

   i=3;
	i=i+2;
	i=2+i;
   t=34*i;
   t=q*i;
   t=i*34;

   for(i=1; i<10; i = i+2) 
   {
      q="pippo";
      if(i==3) continue;
      t=t-2;
      if(t!=7) break;
      printf("Valori di t e i: %d, %d",t,i);
      do {
         t=t+t;
         if(t==6) { break;
            }
         else { continue;
            }
         i--;
         } 
         while(t);
      }
   
   while(i<1 && t>4) {
     q--;
     }
   while(i<1 || t>4) {
     q--;
     }
   do {
     putchar(8);
     }while(i<1 || t>4);
   do {
     putchar(8);
     }while(i<1 && t>4);

   }
 
