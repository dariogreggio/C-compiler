
main(int argc, char **argv)
{
   register int t;
   
   for(t=0; t<argc; t++)
      printf("Arg. no. %d = %s\n",t,argv[t]);
   }

