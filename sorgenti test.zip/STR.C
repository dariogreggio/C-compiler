#include <stdio.h>
#include <string.h>

main()
{
   char *s,*t="banana";
   char ch[30];

   printf("t vale %s\n",t);
   if(!strcmp(t,ch)) puts("uguali!");
   else puts("diversi");
   strcpy(ch,t);
   if(!strcmp(t,ch)) puts("uguali!");
   printf("Lunghezza di t = %d, o %d\n",strlen(t),strlen("picio"));
   strcpy(ch,"fottiti ");
   puts(strdup(ch));
   puts(strupr("che PiCio!"));
   puts(strcat("banana"," al cioccolato"));
   }

