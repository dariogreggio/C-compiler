
main(int argc, char **argv)
{
   int t,z,a;
   
   for(t=0; t<argc; t++) 
      printf("Arg. no. %d = %s\n",t,argv[t+2]);
   z=t+2;

   t=z+a;
   if(a==1) 
     puts("a=1");
   else if(a==2)
       puts("a==2");
   else if(a==3)
       puts("a=3");

   else
       puts("altro");
   }

