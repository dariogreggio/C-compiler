char c;
int b;

main() {
  int t,i,a,q;
  char c1;
  char *p;
   int *p1;

  b+=4;
  b+=t;
  t=t+t;
  i+=4;
  i+=a;
  a+=a;
  t-=2;
  t+=(int)c1;
  (*p)++;
  (*p1)++;
  p[7]--;

  p=&p[8];

  *p <<= 2;
  *p1 >>= 1;
  p[4] <<= a;
  *p |= 2;
  p[3] |=4;
  p[0] += 5;

  t+=b;
  i=i+4;
  q=i+=4;
  q=i=i+4;
  i*=4;
  i*=c1;
  t%=5;
  t/=i;
  t=t%5;
  i=i*4;
  i<<=3;
  i= i<<a;
  i<<=a;
  a>>=2;
  a>>=i;
  i&=4;
  i&=t;
  c1=c1 | 4;
  c1 |= 16;
  c1=c| 0x80;
  i |= 8;
  i |= 0x90;
  i ^= 8;
  }
