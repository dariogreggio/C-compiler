struct picio {
   char pippo;
   unsigned short int cacchio,pippa;		// si pianta in loop se metti unsigned e/o short int
//   int bb : 4;
   long fottiti;
   };

struct picio Alfa,Beta;

struct conArray {
   int a;
   long c;
//   char c;		// DARE ERRORE!
   float z;
   char pirla[7][3];
   char y;
	struct picio *p;
   };

struct conArray Darios;

struct CON_BIT {
	int x:28;
	int y:4;		// 
//	int y:2;		// GESTIRE a-cavallo
	unsigned int z:4;
	};
struct CON_BIT bits;


main()
{
   char a,e;
   register k;
   char *z;
   struct {
      int ciao;
      short *banana;
      } dario,*pippo;
/*static*/   short j[10][5];
	static   short m[10];
   struct picio *y,*pic;
   int i;

i=&bits;
//i=&bits.y;
bits.x=1;
bits.y=3;
bits.y=a;
	i=bits.x;
	i=bits.y;
	a=bits.z;

   i=y->fottiti;
   i=y->cacchio;
   i=y->pippo;
   i=y->pippa;
   i=Darios.y;

   z=Alfa.cacchio;
   z=Alfa.pippa;

i=bits.x;
bits.y=99;

   k=&m[17];
   k=&j[17][0];
//   a=&j[k+2];
   
#if 1
   getchar();
   i=y->fottiti;
   i=Darios.y;

   a+=7;
   y=&dario;
   dario.banana=&a;
   z=&Alfa.pippo;
   k=Alfa.cacchio;
   *z=(*y).pippa;
   e=y->pippo;
   dario.ciao=255;
   y->pippo='3';
   Alfa.pippa=*dario.banana;
//   z=&(*y);
   printf("Dimensione di Alfa:%u oppure %u\n",sizeof(struct picio),sizeof(Alfa));
   printf("Dimensione di Darios:%d\n",sizeof(struct conArray));
   printf("Dimensione di Bits:%d\n",sizeof(struct CON_BIT));
//   Darios.pirla[2][k]='\x46';
   
/* Assegnazione di structs */
   *y=Alfa;
//   Alfa=*y;
   *pic=*y;
#endif
   a=6;
   e = (k*2) ? (a+1) : getchar();
   printf("Ecco: e %d, k %d, a %d",e,k,a);
   }

