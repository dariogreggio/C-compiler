main() {
   char ch,ch1='\170';
   unsigned char ch2=0x90;
   int i,j;
   short a;
   unsigned int k;
	register char ch3;
  
   ch='\xB1';
   i=ch;
   k=ch;
   j=(int)ch;     
   i=ch2;
   j=(unsigned int) ch;
   k=ch2;
   k=(int)ch2;
   printf("Allora: ch = %d, ch1 = %d, ch2 = %u, ch3 = %u, %u \n", ch, ch1, ch2, ch3, 'g');
   printf("e poi: i=%d, j=%d, k=%u\n",i,j,k);
   i=32768;
   j=-32768;
   i=-32780;
   
   }  
