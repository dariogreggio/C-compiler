
#define TRUE 1

typedef unsigned int WORD;

WORD pippo;

#ifndef MICROCHIP
#define ROM
#else
#define ROM rom
#endif

//rom char *mystr="dario";

static int stampa(char *s,short int t)
{
   printf("Dim. di un %s: %d\n",s,t);
   }

main()
{
   int a=TRUE;
  unsigned char b=7;
pippo++;
a=pippo++;
b--;

   stampa("char",sizeof(char));
   stampa("short",sizeof(short));
   stampa("int",sizeof(int));
   stampa("long",sizeof(long));
   stampa("float",sizeof(float));
   stampa("double",sizeof(double));
   stampa("puntatore",sizeof(int *));
   printf("...e infine %d\n",sizeof(a));
   }
 

