#include <stdio.h>
#include <stdlib.h>

main(int argc,char **argv)
{
   printf("Stringa %s, numero %d\n",argv[1],atoi(argv[1]));
   }

 
