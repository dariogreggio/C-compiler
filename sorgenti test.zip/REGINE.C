int i,k,a[9];
int count, ttime;

int controllo () {
    int temp;

   do {
       for(i=1; i<k; i++) {
          temp=a[k]-a[i];
          if((temp == 0) || (abs(temp) == (k-i))) return 0;
          }
      } while(++k < 9);
   return 1;
   }

int decrementa() {
   
   do {
       if(--a[k]) return 1;
       a[k--]=8;
      } while(k);
   return 0;
   }

void main() {                       

   puts("Premi ENTER per iniziare");
   getchar();
   puts("\nLe otto regine");
   time(&ttime);
   do {
      if(controllo()) {
         printf("%d ",++count);
         for(i=1; i<9; i++) putchar(a[i++]+'0');
         k=8;
         }
      } while(decrementa());
   ttime=time(0)-ttime;
   printf("\nTempo: %d.%d\n",ttime/100,(time % 100));
   }


