#include <stdio.h>
#include <ctype.h>

#define INT_FLAG 1
#define STR_FLAG 2
#define VAR_SIZE 6

char *TextP;
char *VarBase,*VarEnd;
char fError;

char *HandleVar(char mode, char *flags) {               // mode = 1 SET, 0 GET
  char nome[4];
  int i;
  char ch;
  char *p;
  char *VarPtr;

  i=0;  
  *flags=0;
  nome[0]=0;
  nome[1]=0;
  nome[2]=0;
  SkipSpaces();
  ch=*TextP;
  if((ch>='A' && ch<='Z') || (ch>='a' && ch<='z')) {
rifo:
	  nome[i]=*TextP++ & 0xdf;
rifo2:
	  switch(*TextP) {
		case '%':
		  *flags = *flags | INT_FLAG;
		  i=nome[0];
		  i=nome[1];
		  nome[0] = nome[0] | 0x80;
		nome[1]=ch | 0x80;
//          nome[1]=0x80;
		  TextP++;
		  break;
		case '$':
		  *flags = *flags | STR_FLAG;
//        nome[1]=nome[1] | 0x80;
	// manca un controllo su entrambi i flags      
		  TextP++;
		  break;
		case '(':
		  goto HndVar2;
		  break;
		default:
		  if(i<1) {
			ch=*TextP;
			if(ch && isalnum(ch)) {
			  i++;
			  goto rifo;
			  }
			}
		  else {
			ch=*TextP;
			if(ch && isalnum(ch)) {
			  do {
				TextP++;
				ch=*TextP;
				} while(ch && isalnum(ch));
			  goto rifo2;
			  }
			}
		  break;
		}
	//  printf("Var: %s, modo %d\n",nome,mode);
	  VarPtr=0;
	  p=VarBase;
	  while(p<VarEnd) {
		if(nome[0]==*p && nome[1]==*(p+1)) {       // trovata
		  VarPtr=p+2;
		  break;
		  }
		p=p+VAR_SIZE;
		}
	  if(!VarPtr) {
		p=VarEnd;
		*p++=nome[0];
		*p++=nome[1];
		*(long *)p=0l;
		VarPtr=VarEnd+2;
		VarEnd=VarEnd+VAR_SIZE;
		}
	//  printf("ritorno var: %x\n",VarPtr);
	  return VarPtr;
	  }
	else {
HndVar2:
	  fError=1;
	  return 0;
	  }
  }
  
