/* Questo programma non deve girare !! */

#define pippo(x) x*2
#define PIRLA 224+(3+4)
#define fotti(x,y,z) (x/3+y+z-PIRLA)

main() {
   
   A=pippo(3);
   B=PIRLA;
   fotti(12,Z,43+6);
   }
 