#include <graph.h>

main()
{
   int t;

   _setvideomode(_HRES16COLOR);
   for(t=0; t<1000; t=t+50) _circle(500,500,t);
   getchar();
   _clg();
   for(t=0; t<500; t=t+30) _ellipse(640,512,t,200);
   }
 
