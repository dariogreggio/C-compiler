main() {
   struct banana {
   char *a1,*a2;
   long z;
   struct banana *next;
   } *root,*curr,old;

   printf("Dimensioni della struttura: %d\n",sizeof(struct banana));
   root=malloc(sizeof(old));
   root->a1=(char *)calloc(80,sizeof(char));
   puts("Allocati 80 caratteri.");
   root->next=malloc(sizeof(old));
   root->next->next=0;
   curr=root;
   while(curr) {
      printf("Elemento attuale: %p\n",curr);
      curr=curr->next;
      }
   }


