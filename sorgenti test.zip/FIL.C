#include <stdio.h>

void NoOpen()
{
   puts("Non riesco ad aprirlo");
   }

main() {
   FILE pippo;
   int ch;

   if(pippo=fopen("$.DARIO","W")) {
      for(ch=1; ch<10; ch++) fputs("crepa, Bastardo",pippo);
      fclose(pippo);
      }
   else NoOpen();
   exit();

   if(pippo=fopen("$.test","r")) {
      while((ch=getc(pippo)) != EOF)
      printf("Carattere %x alla posizione %d\n",ch,ftell(pippo));
      fclose(pippo);
      }
   else NoOpen();
   }
 
