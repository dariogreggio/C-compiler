#include <stdio.h>
#include <malloc.h>

main() {
   int i=3;
   int j;
   char *a,*b="fatti fottere, stronzo!";


   cls();
   while(i--) {
      j=strlen(b);
      a=(char *)malloc(strlen(b));
//      a=malloc(16);
      printf("Il prossimo ind. (%d,%d) e' %x\n",i,j,a);
      strcpy(a,b);
      }

   a=malloc(0x1000);
   a=malloc(0x10);
   printf("L'ultimo indirizzo e' %p",a);
   a=malloc(0x700);
   printf(" indirizzo: %p",a);
   }

 
