int printf(char *,...);
struct _DARIO {
	short int	minchia;
	long papa;
	char fr;
	} dario;

#define SEC_TIME 1000

long l=3;
char *p="Froci";
unsigned char prova[5];
unsigned char provaaa[5][7];

void test() {
	unsigned char ch;
	unsigned int a,b,c,n;

  l=clock()+(SEC_TIME*3);
  l=l+(SEC_TIME*3);

//	n=provaaa[1][2];
	ch=prova[2];
	n=a+b;
	clock(a+b);
	clock(a+7);
	n-=2;
	}

#if 0

int stampa(int n) {
	unsigned char n1=n;
	unsigned char prova2[4];

n1+=2;
			n1=provaaa[1][2];

	dario.papa=&prova2;

	dario.papa=&prova2[2];
	n1=&prova2[2];
	
	dario.minchia=128;
	dario.papa=9;
	dario.fr='$';

	switch(n1) {
		case 0:
			n1=n--;
			n1=++n;
			break;
		case 3:
			printf("i=%d\n",n);
			break;
		default:
			n1=7;
			n1=(char)n;
			n1=prova[3];
			n1=prova2[1];
			n1=provaaa[1];
			n1=provaaa[1][2];
			n1=provaaa[1][n];
			break;
		}
	return 100;

	}

main() {
	short int i;
	register char ch;
	int *ip;

	ch=*p;

	ch=*p++;
	*ip=967;

//	if(i==1)
//		l+=(long)i;
//	l-=i;
	ch='A';
	ch=*p;
	ch=*p++;

  *(char *)0x800100=34;
  *(char *)0x8001=34;

	ip++;
	i=2;
	i=0;
	l=3;
	i=7;
	i+=9;
	l=l+3;
	l=ch;
	ch=*p;
	printf("Hello, world! %s, %c",p,ch);
	for(i=0; i<10; i+=2)  {
		stampa(i);
		p++;
		ch--;
		}

	}

#endif
