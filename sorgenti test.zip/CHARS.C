#include <stdio.h>
#include <ctype.h>

esponi(char *s,int t) {   

   printf("%s = %s\n", s, t!=0 ? "VERO" : "FALSO");
   }

main() {
	register short i;

   for(i=-1; i<=0xff; i++) {
      printf("Carattere %x = %c\n",i,(i>31) ? i : '.');

      esponi("Alpha ",isalpha(i));
      esponi("Upper ",isupper(i));
      esponi("Lower ",islower(i));
      esponi("Digit ",isdigit(i));
      esponi("XDigit",isxdigit(i));
      esponi("Ctrl  ",iscntrl(i));
      esponi("Punct ",ispunct(i));
      esponi("Alnum ",isalnum(i));
      esponi("Print ",isprint(i));
      esponi("Space ",isspace(i));
      esponi("ASCII ",isascii(i));
      putchar('\n');
      getchar();

      }         
   }
 
