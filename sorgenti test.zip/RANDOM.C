main(int argc, char **argv) {
   register i;

   for(i=0; i<100; i++) printf("%d\n",rand());

   }


