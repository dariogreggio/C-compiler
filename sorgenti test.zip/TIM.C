#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>

//#define FOREVER for(;;)

main()
{
   time_t pippo;
	int8_t i;

   FOREVER {
//   for(;;) {
      time(&pippo);
      printf("Ticks %d\n",pippo);
      }
}
