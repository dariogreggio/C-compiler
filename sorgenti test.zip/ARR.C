main(int argc,char *argv[])
{
   char *s;
   static char ch[100];
   int *p,t[20];
   register z;

   p=t;
   ch[34]='D';
   *(ch+3)=ch[20];
   ch[67]++;
   --t[-1];
   s="piccione\n";
   (*p)++;
   s[0]='P';
   while(*s) {
      printf("il char E' %c\n",*s);
      putchar(*s++);
      *p++=*s;
      z=p[0];
      }
   for(z=0; z<25; z++) printf("t[%d] = %d\n",z,t[z]);
   }

 
