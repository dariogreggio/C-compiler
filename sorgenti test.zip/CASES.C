static int e;
enum MINCHIA {
	minchia99=1,
	culattone,
	puttano
};

main() {
   int c=50,d;
//   int e;
   char *s="pippo\a\n";
   int *p;
   char i,a;

   for(a=8; c=a; a--) {
     d=--a;
     e=3;
     d=e--;
     p=&c;
     p=&e;
      switch(a) {		// >5 e con range > 2x cases, linear search (8 su 68000
         case 1:puts("ciao");
            break;
         case 10:
            break;
         case 100:
            break;
         case 101:
            break;
         case 102:
            break;
         case culattone/*2*/: 
            puts("ciao\n");
case puttano:
         case 4: 
            printf("a=%d\n",a);
            break;
         case 6:
         case 17:
            continue;
         case -5:
            e=*s;
            break;
         default:
            printf("fottiti\a\n");
            break;
         }
      printf("%d\n",c);
      }

   switch(a) {			// <5, compare/jmp
     case 0:
     case 2:
       getchar();
       break;
     case -1:
       break;
     case 10:
       a++;
       break;
     default:
       break;
     }

   switch(e) {			// >5 con range limitato, jump table (8 su 68000

     case 0:
     case 2:
     case 3:
     case 4:
       getchar();
       break;
     case -1:
       break;
     case 8:
       a++;
       break;
     case 6:
     case 1:
     case 9:
     default:
       a--;
       break;
     }
   return i;
   return c;
   return;
   return (long)i;
   }


 
