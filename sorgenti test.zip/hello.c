//#define const		// PATCH! gestire const  ora lo prende ma NON nei parametri funzione
short int aa;			//
const  short int aaa;			//const   (ora lo salta ma non va oltre col tipo


#define O_APPEND   157     // culo

#include <fcntl.h>
//#include <conio.h>
#include <ctype.h>
//#include <time.h>

int printf(char *,...);
short int strlen(char*);

interrupt void __attribute__(naked) piciu() {
int culo=8;
#ifdef MC68000
_asm	move culo,d1
#endif
#ifdef I8086
_asm	lea si,[culo]
#endif
	}

int stampa2() {
#ifdef MC68000
_asm {
	move.l d0,a0
	moveq #9,aa
	}
#endif
#ifdef I8086
_asm {
	mov ax,[aa]
	mov di,9
	}
#endif
}


int stampa(int n) {
//int t;
char *p;

aa=aa+n;
aa+=n;
aa=aa*n;


//p=90;
*p=55;
aa=*p++;
aa++;
n+=5;
aa <<= 1;
aa <<= n;
aa = aa >> n;
n<<=2;
n= n >> 1;
//aa >>= 9;
aa=strlen("aaa")-1;
aa=10-strlen("aaa");
n=O_APPEND;
	printf("i=%d\n",n);
	return 0;
	}

main() {
/*	short int*/char i;

	printf("Hello, world!");
	for(i=0; i<10; i++) 
		stampa(i);
	}

