// prova #if #endif ecc

//#define PIPPO 1

#if MC68000
#include <conio.h>

#if !defined(Z80)
printf("culo");

#else

int ciao(void);

#endif

#endif
