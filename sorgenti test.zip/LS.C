#include <riscos.h>

main(int argc, char **argv) {
   struct find_t ff;
   register int i;   
   char buffer[64];

   printf("RISC-OS v%d.%d\n\n",_osversion >> 8,_osversion & 0xff);

   if(argc > 1) strcpy(buffer,argv[1]);
   else strcpy(buffer,"$");

   _os_findfirst(buffer,0,&ff);
   do {
      printf("File %s, lungo %u bytes, tipo %x, %x\n",
         ff.name,ff.size,ff.filetype,ff.type);
      i=_os_findnext(&ff);
      } while(i); 
   }


