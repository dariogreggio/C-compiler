char c1,c2;

main() {
  int a,b;
  int c;
  register d;
  long t;
  char *p;
  char p1;
  int *n;

  a=3;
  c1=c2+c1;
  if(!a) p1++;
  if(a) p1++;
  if(a & 2) p1++;
  if(a & 5) *p++;
  if(p1 & 2) p1++;
  if(p1 & 1) p1++;
  if(p1 & 5) *p++;
  if(a + 5) *p++;
  if(*n) *p++;
  if(*(int *)c) *p++;
  if((a<5)) goto ciao;
  if(!(a<5)) goto ciao;
  if(*p < 5) goto ciao;
  if(*p < p1) goto ciao;
  if(*n > 340) goto ciao;
  if(n[2] > 340) goto ciao;
  if(b==12701) goto ciao;
  b=a>4 ? 3 : a;
  b=42 ? 3 : a;
  c=t<=7;  
  c=t+d;  
  a=c & b;
  a=c > d;
  a=(b>=5)*3;
ciao:
  if(t != a) puts("Diverso");
  if(t != (long)a) puts("Diverso");
  if((long)a != t) puts("Diverso");
  if(b == c) puts("Uguali");
  if((a==5) && (t==b)) {
    a=6;
    }
  if((a<4*3) && (d<=b)) {
    d=6;
    }
  if((a<4*3) || (d<=b)) {
    d=6;
    }
  b=(d==34) || (d>=b);
  b=(a==34) && (d>=b);
  b=(a==34) || (d>b);
  if((a==5) && (t==b) && (a==b)) {
    a=6;
    }
  if((a!=5) || (t==b) || (a==b))
    a=6;
  if((a!=5) && (t==b) || (a==b))
    a=6;
  if((a!=5) || (b==3) && (a==b))
    a=-32768;
  if(((a!=5) || (b==3)) && (a==b))
    a=-a;
  if((3) && c< 4) d=1;
  if(a<b || 4567) d=4;
  }

