
main() {
  int a,b,t;
  char c;
  char ch[4];
  long l;
  
  if((a==5) && (t==b) && (a==b)) {
    a=6;
    }
  if((a!=5) || (t==b) || (a==b))
    a=6;
  if((a!=5) && (t==b) || (a==b))
    a=6;
  if((a!=5) || (b==3) && (a==b))
    a=-32768;

  if(a && c)
    exit();
  if(a && ch[a] & 3);
  if(ch[a] & 3);
  if(c & 3)
    printf("l=%ld",l);
  a++;
  if(((a!=5) || (b==3)) && (a==b)) a=-a;
  if((a!=5) && ((b==3)) || (a==b)) a--;
  if(c)
    exit();
  }

