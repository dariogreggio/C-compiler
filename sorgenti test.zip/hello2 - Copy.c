#include <ctype.h>

int __attribute__(frocio) Punti;
void (*OldCtrl)(int ),*ww;


enum MINCHIA {
	minchia99=1,
	culattone=2
};

int lPosX[20],lPosY[20];
extern int culo=1;
short int *p="Frocinn\r";
float fl=3.1415926535;
char *p7="Froci\n\r\x1b";
#if 1


int memcpy(void*, void*,int);
void stampa(int,char);


unsigned char provaaa[5][7];
signed char c3='2',cc;
unsigned char ch,c2,c9=1,d7=3;

merda;
volatile char Bx,By,Bp;


//int printf(char *,...);
	short int minchia;


#define PIPPO "cpu##MC68000"
char *z=PIPPO,*qq,ss;


struct _DARIO {
	short int	minchiazza;
	long papa;
	char fr;
	} dario;

#define SEC_TIME 1000
/*const */unsigned char BitTable[8]={ 0x80,0x40,0x20,0x10,8,4,2,1 };
const char *co=0x10000;


long l=3;
char prova[5];

int clock(short,int);
#endif
short strlen(char far *);
void test2() {
int y;
//l++;
}


void test() {
	signed int c5;
	unsigned int a,b,c,n;
	unsigned char a2,b2,c2;
	register signed char d;
	short *ppp;
register 	char far * pp4;
int Punti2;
 char *OldText=a=0,*OldVar;

  a=b=clock(2,1);
  a=b=c;

b=&prova[17];			// SISTEMARE!!
b=&prova[a];			// SISTEMARE!!
c=&prova;
b2=prova[17];
a=*(((unsigned short *)&c5)+1);


//while(*OldVar!= '\"' && *OldVar  && *OldVar) ;
a=1;
while(a!=0 && b!=0);

#if 1
cursor(a+(5/2-1),a2+(1 >> 1));


ch=*(++OldVar);		// d0 in a0
ch=*(OldVar++);		// d0 in a0
l=d;		// copia reg sia in d0 che in d7 (sarebbe da ottimizzare...
a=*(((unsigned short *)&b)+1);
*(unsigned short *)ppp=(*(unsigned short *)&a)+a2;		// non raddoppia a2 MA � GIUSTO!
*(unsigned short *)ppp=*((unsigned short *)&a+a2);		// ok


d=toupper(a2);
//d= ((islower(c5)) ? _toupper(c5) : (c5)) ;
d= ((a2) ? 1 :a2);


//d=toupper((*(OldText+1)));
//		if(toupper(c5)=='T' && toupper(*(OldText+1))=='I') ;
a=clock(1,2) + (c2*(80/3));		// verificare mult char*short, viene char
a=clock(1,2) + (((short int)c2)*(80/3));		// verificare mult char*short, viene char


BitTable[a]=*OldVar++;		//salva * e non &0xdf
BitTable[n]=*OldVar++ & 0xdf;

if((*(unsigned short int *)OldText) && 44)
*ppp=(unsigned long)*((unsigned char *)a);
if((*(unsigned short int *)(OldText)))
a=*((long *)OldVar);	// d0 in a0



a=*(((unsigned short *)&c5)+1);

BitTable[a]=*OldText++ & 0xdf;		//salva * e non &0xdf
if(pp4[1] == a2);		// manca d7 register in a0 (o d0)
a=*((long *)OldVar);	// d0 in a0

if(*((long *)OldVar) > a)
	(*ppp)++;
*(((unsigned short int *)pp4)+1)=d;
c5+=*ppp;
*p=BitTable[2];
c5=BitTable[2];
a=BitTable[n];
a=BitTable[1];
a=*(((unsigned short *)&c5)+1);
*p++=BitTable[0];
*(pp4+c5+1)=0;


*ppp++=a | 0xc0;
*++ppp=a | 0x30;
BitTable[n]=*OldVar++ & 0xdf;
while(*pp4++);
while(*pp4);
*p++=BitTable[0];

c5=*ppp;
c5+=*ppp;
c5=*ppp+*ppp;
l=prova[*ppp];
*ppp=0;
l=*pp4+*ppp;
	*pp4 = *ppp-14; 


if(*pp4 == *ppp || *ppp>*pp4)			// ERRORE 27/11
;




l=prova[*ppp];
*(pp4+c5+1)=0;
	*pp4 -= 14; 



a=b+a2;
a=b+d;



a=*(((unsigned short *)&c5)+1);
a=&c5+1;

*OldText |= 1;

d=*OldText;
OldCtrl(a);

	a=culattone;
pp4=lPosX; pp4=&co;

a=c5 -('A' - 'a');
a=c5 -(15 - 4);


cursor(a+(5/2-1),a+(3 >> 1));
#endif


	if(!clock(1,2))
;
//*(ppp+2)=0x86;
//*ppp++=0x86;
ppp[2]=c5;

#if 1
*ppp++=0x86;

a+=ch;

d+=c;
//Punti=5,d=4;

l+=a;

//l+=;		DARE ERRORE!
*ppp=0;
while(a=*ppp);

a=clock(0,0) +clock(1,1);

d=(a>clock(d,d));
a=b=c=0;

;
l=d;
d &= 4;
d += 1;
d+=1000;

#if 1
	*ppp <<=13; 
	*ppp = *ppp>>13; 
	d <<= 17;
	c5 <<= 7;
	c5 = c5<<17;
	c5 = 1 << 3;
	c5 = 1 << d;
	c5 = 1 << c5;
	c5 = '\s' << c5;
	c5 = 1 + c5;
	a = 333 << b;
	*pp4 +=c5; 
	*pp4 +=13; 
	*pp4 = 22-*pp4; 
	ppp = c5-strlen(ppp); 
	pp4 = 22-strlen(ppp); 
	pp4 = strlen(ppp)-22; 
	pp4 = 22+strlen(ppp); 
	ppp +=13; 
	*ppp <<=13; 
//	*ppp ++; 
//	*ppp +=4;
//	*ppp=BitTable[b] ? 0 : 1;


//	if(a!=1 || b==3)
		b++;
//	if(a!=1 || b==3 || c==4 )
		b++;
//	if(a!=1 || b==3 || b==4 || b==69)
		b++;
	if(a!=1 || b==3 || b==4 || b==69  || b==999)
		b++;
	if(a!=1 && b==3)
		a++;
	if(a!=1 && b==3  && c==7)
		a++;
	if(a!=1 && b==3  || c==17)
		a++;
	if((a!=1 && b==3)  || c==17)
		a++;

  a=time()+(SEC_TIME*3);
  while(a>=time())
	;
	ch=40-strlen(p);
	ch=strlen(p)-5;

Punti*=Bp;
Punti2+=Bp;

	  if(ppp[l])
;
	  if(provaaa[l][3])
;
	  a=provaaa[l][6];

a=*(ppp+2);
	ch=prova[n];
	ch=provaaa[2][3];
	ch="provaaa"[n];
	ch="provaaa"[2];
	ch=provaaa[4];
	ch=prova[4];
	  if(ppp[l])
;
	  if(provaaa[l][6])
;
	  a=ppp[l];
	  if(ppp[3])
	  if(ppp[3] >= n)
a=ppp[1];
a=*(ppp+2);
p="froci";
if(!cc)
		  puts("\nPronto.");
c2=c5 & (0x1 | 0x2 );
#endif
#endif


#if 1
//a=p-prova;

	a+=1;
	d+=5;
	a=b << 2;
	d=d>>1;
	d >>= 1;
	if(ch<c2)
	n=10;
//	p="froci";
	if(c5<4)
	n=10;

	ch=40-strlen(p);
	ch=(rand() % 19)-9;

	clock(ch,a);
	clock(ch+1,a+3);
	clock(ch+a,ch+b);
	printf("%1d00",n);
#endif
//	clock(ch+1,a+3);

#if 1
	ch=*p;
	ch=prova[2];
	ch=*p++;
	l='2';
  l=clock(7,77)+(SEC_TIME*3);
  l=l+(SEC_TIME*3);

	n=provaaa[1][6];
	ch=prova[2];
 	ch=p[3];
	ch=*(p+8);
	n=a+b;
	clock(a+b,1);
	clock(a+7,1);
	n-=2;
#endif
	}

char DirectBuf[80];
char *TextP;

short tv;
/*fastcall*/ void stampa( int aa,char cc) {

int  ff;
char *OldVar;
	char p[42];
long ToVal;

#if 1

ff|=aa;
ff-=aa;
ff/=aa;
tv*=aa;
ff^=aa;
ff<<=aa;





cc=p7[2];
cc=BitTable[2];
p7[2]++;
provaaa[3]++;
cc=provaaa[3];
*TextP++=cc | 0x80;
*OldVar++=cc | 0x80;

ff+=ch; 
ff+=(unsigned long)(ch-'0'); 
ff+=cc-'0'; 
if(*TextP & 2) ;
if((*TextP & 2) || (cc  & 2)) ;
	cc=*TextP;
	cc=p[39];
*(long *)TextP=0l;
aa=&tv+4;
*(long *)&tv=0l;
*(long *)123456=789;

  *TextP=p7[1];  //casini




*TextP=0x86;
while(*TextP);		// 
while(cc=*TextP);		// se doppio puntatore esce vuoto


if(TextP[1] == '\"')		// legge doppio
;
if(*TextP == '\"')
;
if(lPosX[1] <= '\"')
;
*TextP++=lPosX[1];

 ff=*TextP++;
 ff=*TextP-- & 0xdf;
 TextP=DirectBuf[2];
lPosX[1]=lPosX[cc];

//	if(!(lPosX[cc] & 128))
;
cc=!(lPosX[cc] & 128);

cc=lPosX[cc] > 12;

	if(lPosX[3+2]==1)
;
	cc=lPosX[cc-1];
	stampa(lPosX[cc-1],*TextP--);

	if(cc & ff)
;
	if((lPosX[cc] & 128))
;



	if(cc==*OldVar) 
;
	cc=tv -= cc;

 if(OldVar <= ToVal)             // patch per skynet!!!!

;
 if(OldVar > ToVal)             // patch per skynet!!!!


	//ff=aa|0;
fl++;

	if(ToVal)
;
	if(!ToVal)
;
	if(!clock(1,2))
;
	if(clock(1,2))
;




ToVal = ToVal *3;
cc=DirectBuf[aa];
if(DirectBuf[aa]==cc /* && DirectBuf[0]!=cc */) 

ff=aa-3;
ff=3-aa;
//ff=aa^0;
ff|=aa;
ff&=3;
ff ^= cc;
	ff=ff& aa;
/*	ff=ff;
	if(ff==ff+42)
;
	ff*=3;
	ff = ff + cc;
	cc += cc;
cc=cc/ff;
cc='\x5'/cc;
cc=cc%5;
cc='\x0'%cc;
cc='\x1'/cc;
	ff = ff%1;
		ff=1%ff;
	ff /= 1;
		ff='\x0'%ff;
	ff = ff/9;
	ff = 11/ff;
	ff=aa/2048;
	aa/=2;
	aa<<=8;
	aa/=2;
	cc/=3;
	aa/=256;
	aa>>=9;
	ff=aa+2;
ff=aa;
	ff |= 2;
	ff += 2;
	ff += 1400;
	ff &= 8;
	ff=ff | 4;
	ff=4 ^ aa;
if((ff &= 4) < 0)
	cc++;
	ff=4 + aa;
	ff= ff-cc;
	cc='3'+cc;
	cc='3'-cc;
	*/
#endif
	}
#if 1
int stampa1(int n) {
	unsigned char n1=n;
	unsigned char prova2[4];

n1+=2;
			n1=provaaa[1][2];

	dario.papa=&prova2;

	dario.papa=&prova2[2];
	n1=&prova2[2];
	
	dario.minchiazza=128;
	dario.papa=9;
	dario.fr='$';

	switch(n1) {
		case 0:
			n1=n--;
			n1=++n;
			break;
		case 3:
			printf("i=%d\n",n);
			break;
		default:
			n1=7;
			n1=(char)n;
			n1=prova[3];
			n1=prova2[1];
			n1=provaaa[1];
			n1=provaaa[1][2];
			n1=provaaa[1][n];
			break;
		}
	return 100; 

	}
#endif

#if 1
main() {
	short int i;
	register char ch;
char *p;
long l=3;
	int *ip;

	ch=*p;
*p+=7;
p7[5]+=4;
p7[5]=p7[5]+4;
*p+=17;

	ch=*p++;
	*ip=967;

//	if(i==1)
//		l+=(long)i;
//	l-=i;
	ch='A';
	ch=*p;
	ch=*p++;

  *(char *)0x800100=34;
  *(char *)0x8001=34;

	ip++;
	i=2;
	i=0;
	l=3;
	i=7;
	i+=9;
	l=l+3;
	l=ch;
	ch=*p;
	printf("Hello, world! %s, %c",p,ch);
	for(i=0; i<10; i+=2)  {
		stampa(i,44);
		stampa(88,ch+2);
		p++;
		ch--;
		}

	}

#endif
