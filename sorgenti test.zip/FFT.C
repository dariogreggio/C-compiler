#include <conio.h>
#include <stdio.h>
#include <graph.h>
#include <stdlib.h>
#include <math.h>

main(int argc, char **argv) {
   register int i, hs, x, x1;
   float dati[64], g, real, imag, fft, fase;
   int y=0;

   int lsb, msb, mux=0x3e0, value=0;
   int start = 0x3e1, read_lsb=0x3e2, read_msb=0x3e3;
   int dato, delay;
   int periodo = 16;

   if(argc>1) periodo=atoi(argv[1]);

/*
   outp(mux, value);
   for(i=0; i<64; i++) {
      outp(start, value);
      msb=inp(read_msb);
      lsb=inp(read_lsb);
      dati[i]=(msb & 0x0f) * 256 + lsb;
      if(((msb & 0x80)) == 0x80)
         dati[i]=-dati[i];
      for(delay=0; delay<=200; delay++);
      }
*/
   _setvideomode(_VRES16COLOR);
   _setcolor(1);
   for(i=0; i<64; i++) {
      dati[i]=sin(PI/periodo*i)*200;
      x=i*10;
      _moveto(x,0);
      _lineto(x, -dati[i]+200);
      }
   getchar();
   
   for(hz=0; x1=0; hz<32; hz++, x1+=10) {
      real=0.0;
      imag=0.0;
      for(x=0; x<64; x++) {
         g=(PI*hz*x)/64.0;
         real+=(dati[x]*cos(g))/64.0;
         imag-=(dati[x]*sin(g))/64.0;
         }
      fft=2*sqrt(real*real+imag*imag);
      if(real != 0)
         fase=atan(imag/real);
      _setcolor(7);
      _moveto(x1,480);
      _lineto(x1,480-fft/10);
      _setcolor(3);
      _moveto(x1+320,480);
      _lineto(x1+320, 480-fase*70);
      }
   }



   }
