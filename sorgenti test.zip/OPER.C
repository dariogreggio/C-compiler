#include <stdio.h>
#include <math.h>

main() {
   register int f,g;
   register h;
   register i=20000;

   f=205;
   g=750;
   h=g/f;
   printf("%d diviso %d fa: %d con resto %d\n",g,f,h,g%f);
   printf("mentre 7/3 fa %d con resto %d",7/3,7%3);
   printf("\nIl seno di 45 e 90 gradi e' %d %d\n", sin(45), sin(90));
   printf("...mentre la radice quadrata di 625 e' %d\a\n",sqrt(625));
   
   printf("Tempo = %d\nTempo dopo %d div.= ",time(0),i);
   while(i--) h=g/f;
   printf("%d\n",time(0));

   i=1000;
   printf("Tempo = %d\nTempo dopo %d radici = ",time(0),i);
   while(i--) h=sqrt(6561);
   printf("%d, %d\n",time(0),h);
 

   }


