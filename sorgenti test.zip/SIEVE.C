
void sieve(unsigned int iters) {
   unsigned int limite=1;
   unsigned int i;
   unsigned totale,k;
   char *sieve;

   if(!(sieve=calloc(iters+1,sizeof(char)))) {
      puts("Memoria insufficiente");
      exit(99);
      }
   printf("Sieve: %u iterazion%c\n",limite,limite == 1 ? 'e' : 'i');
   totale=0;
   for(i=2; i<= iters; i++) {
      if(!sieve[i]) {
         for(k=i*2; k<=iters; k=k+i;)
            sieve[k]=1;
         totale++;
         printf("Numero primo = %d\n",i);
         }
      }
   printf("Numeri primi trovati [1..%u] = %u\n",iters,totale);
   free(sieve);
   }

main(int argc, char **argv) {
   
   if(argc > 1) sieve(atoi(argv[1]));
   else sieve(1);
   }
                 

