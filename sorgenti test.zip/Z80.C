// #include <stdio.h>
// #include <z80.h>

#if 0
interrupt void pippo() {
  int i;

  i++;
  }

int pippo2(int k) {

//  *(char *)k=1;
  }
#endif

int pippo3(int k) {

  *(char *)k=34;
  *(char *)0x80010=34;
  *(short int*)k=34;
  }

main()
{
//   struct REGS in,out;
  int i;

   _asm {
    ld hl,pippo
    ld a,i
    xor a
    ld c,b
    }
   
   }
  
