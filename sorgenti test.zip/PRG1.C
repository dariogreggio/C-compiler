#ifdef DARIO
#include <conio.h>
#endif

#define MAX 10
#define fotti(x) puts(\
x)
   #define MIN 1

#if DARIO
  long a;
#endif
typedef int FILE;

int a,b;
register int x;
char ch=1;
short t[15][3];
extern int dario;
extern char Dar1[25];
char *p1="Accasciati\a";
unsigned int cz;
FILE f;
float fl,dd;

main()
{
   int y,i;
   register int alfa;
   long z;
   void printf(char *,...);
   long *p;
//   int *p;
   unsigned int u;
   char *str;
   char pp1[4];
   float dd2;
   
   p1="Fottiti";
   p=p1;

   fl=300.45;
   dd2=fl;
   z=(long)cz;
   z=(unsigned long)cz;
   z=(long)a;
   a=4;
   b=22543;
   y=(5+12)*2;
   ch='d';
   x=255;
   alfa=y+3;
   alfa=77;
   z=768;
   z=-17;
   y=-143002;
   z=x;
   x=y-3,a+alfa+b;
   x=y=alfa+MIN;
   x=(y=3,ch);
   str=p1+5;
   b=~a + y & !x;
   ch=++b * --alfa;
   ch=b / 7;
   z=-*(p+4)+~ch;
   a=(int)ch << 3;
   a=*(int *)ch; 
   *(str + 3)='G';
   *(4+str)='G';
   a=4+i;
   a=i+4;
   a=4 | i;
   a=256 | i;
   a=i | 7;
   a=1008 & getch();
   *p=14000L;
   *p=clock();
   *(p+6)=14000L;
   dario=printf;
   
   a=a+(b+3-(i+u));
   a=a+(b+3);
   printf("a vale %d, z vale %ld\n",a,z*(z+2));
   ch=MAX;
   u=200;
   x=u << 9;
   a=b >> ch;

   t[3][1]=getc();
   p1[0]=ch;
   p1[1]=ch;
   p1[10]=p1[20];
   pp1[0]=1;
   a=pp1[1];
   pp1[1]=3;
   ch=p[a];
   ch=p[6];
   ch=p[100];
   ch=p1[5];
   ch=getc();
   }

kk;

void printf(char *s)
{
   static short pippo;
   int i;
   int *p2;

   pippo++;
   --kk;
   a=kk++ + b;
   x=(kk+5*(ch=7));
   x=5+kk;

   while (*s++) {
      putchar(*s);
      putchar('\n');
      }
   i=*p2;
   i=*(p2+4);
   p2++;
   *p2++='G';
   }
 
int dummy() {
   char c;
   int *a=9;
   short s;
   char *z;
   int i;
   
   z=t;
   while((*a)--) {
//   while(*a--) {
      --(*a);
      a=a-1;
      a-=1;
      } 
   }
