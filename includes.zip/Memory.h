/* Memory.h for moving memory blocks
   (C) G.Dar 1989
   (C) ADPM 1994-2001
   */

#ifndef _SIZE_T_DEFINED
   typedef unsigned int size_t;
   #define _SIZE_T_DEFINED
#endif

#ifndef NO_EXT_KEYS
   #define _CDECL cdecl
#else
   #define _CDECL
#endif

void *memccpy(void *, void *, int, unsigned int);
void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
int memicmp(void *, void *, unsigned int);
void *memset(void *, int , size_t);
void movedata(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);

