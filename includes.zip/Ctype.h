/* CTYPE.H, character handling routines and macro for Z80
   by G.Dar & Microsoft
   [ANSI/System V]
   (C) 1989
   (C) ADPM 1994-2001
	 (C) Dario's Automation 2025
   */
                  
extern unsigned char _ctype[];

#if 0		// faccio macro
#ifdef Z80
char toascii(char);
char tolower(char);
char toupper(char);
#else
#ifdef MC68000
char toascii(char);
char tolower(char);
char toupper(char);
#else
int toascii(int);
int tolower(int);
int toupper(int);
#endif
#endif
#endif

#define _UPPER  0x1
#define _LOWER  0x2 
#define _DIGIT  0x4
#define _SPACE  0x8

#define _PUNCT   0x10
#define _CONTROL 0x20
#define _BLANK   0x40
#define _PRINT   0x40
#define _HEX     0x80

#define isalpha(c) (_ctype[c] & (_UPPER | _LOWER) )
#define isupper(c) (_ctype[c] & _UPPER)
#define islower(c) (_ctype[c] & _LOWER)
#define isdigit(c) (_ctype[c] & _DIGIT)
#define isxdigit(c) (_ctype[c] & _HEX)
#define isspace(c) (_ctype[c] & _SPACE)
#define ispunct(c) (_ctype[c] & _PUNCT)
#define isalnum(c) (_ctype[c] & (_UPPER | _LOWER | _DIGIT) )
#define isprint(c) (_ctype[c] & (_BLANK | _PUNCT | _UPPER | _LOWER | _DIGIT) )
/* vedere come fare per PRINT / BLANK ! */
#define isgraph(c) (_ctype[c] & (_PUNCT | _UPPER | _LOWER | _DIGIT) )
#define iscntrl(c) (_ctype[c] & _CONTROL )
#define isascii(c) ( (unsigned short int) (c) < 0x80 )

//#define _toupper(c) ( (c) - ('A' - 'a'))
#define _toupper(c) ( (c) & ~0x20)
//#define _tolower(c) ( (c) - ('a' - 'A'))
#define _tolower(c) ( (c) | 0x20)

#define toupper(c) ( (islower(c)) ? _toupper(c) : (c) )
#define tolower(c) ( (isupper(c)) ? _tolower(c) : (c) ) 
#define toascii(c) ( (c) & 0x7f )

/* MS C 2.0 extended type macros */

#define iscsymf(c) (isalpha(c) || ((c) == '_'))
#define iscsym(c) (isalnum(c) || ((c) == '_'))


#ifndef Z80

/* G.Dar extensions for italian chars & jollies */

#define isjolly(c) (( (c) == '*' ) || ( (c) == '?' ))
#define isitalian(c) (( (c) == 'a') || ( (c) == 'e' ) || ( (c) == 'e' ) || ((c) == 'i' ) || ( (c) == 'o' ) || ( (c) == 'u' ) )

/* G.Dar macros for vowels & consonants */

#define isvowel(c) (( (c) == 'a') || ( (c) == 'e' ) || ( (c) == 'i' ) || ( (c) == 'o' ) || ( (c) == 'u' ) )
#define isconsonant(c) ( !isvowel(c) )

#endif


