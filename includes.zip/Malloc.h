/* MALLOC.H, memory allocation routines for the Archimedes
   (C) G.Dar 1989
   (C) ADPM 1994-2001
   (C) Dario's Automation 2025 - small version/68000
   */

#ifndef _SIZE_T_DEFINED
   typedef unsigned int size_t;
   #define _SIZE_T_DEFINED
#endif
                                  
#ifndef Z80
#ifndef MC68000

#ifndef _HEAPINFO_DEFINED

typedef struct _heapinfo {
   int *_pentry;
   size_t size;
   int _useflag;
   } _HEAPINFO;

#define _HEAPINFO_DEFINED

#endif
#endif

extern unsigned int _amblksiz;

void *alloca(size_t);
unsigned int _freect(size_t);
int _heapchk(void);
int _heapset(unsigned int);
void *sbrk(int);
int _heapwalk(struct _heapinfo *); 

#endif

void *calloc(size_t, size_t); 
void *expand(void *, size_t);
void free(void *);
void *malloc(size_t);
size_t _memavl(void);
size_t _memmax(void);
size_t _msize(void *);
void *realloc(void *, size_t);
size_t stackavail(void);
                           

