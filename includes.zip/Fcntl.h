/* FCNTL.H, containing the declarations for low-level file I/O
   (System V)
   (C) G.Dar 1990
   (C) ADPM 1994-2001
   */

#ifndef Z80

#define O_RDONLY   0x0000
#define O_WRONLY   0x0001
#define O_RDWR     0x0002
#define O_APPEND   0x0008          /* writes done at eof */

#define O_CREAT    0x0100
#define O_TRUNC    0x0200
#define O_EXCL     0x0400

/* text file have <cr><lf> translated to <lf> while reading,
   and <lf> expanded to <cr><lf> in writing */

#define O_TEXT     0x4000        /* translated */ 
#define O_BINARY   0x8000        /* untranslated */

#define O_RAW    O_BINARY

/* Open handle inherit bit */

#define O_NOINHERIT    0x0080

#endif

