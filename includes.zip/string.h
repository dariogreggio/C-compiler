/*-------------------------------------------------------------------------
   string.h - ANSI functions forward declarations    
  
       Written By -  Sandeep Dutta . sandeep.dutta@usa.net (1998)
   (C) Dario's Automation 1994-2025 - small version/68000

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
   
   In other words, you are welcome to use, share and improve this program.
   You are forbidden to forbid anyone else to use, share and improve
   what you give them.   Help stamp out software-hoarding!  
-------------------------------------------------------------------------*/


#ifndef __STRING_H
#define __STRING_H 1

extern char *strcpy (char *, char *);
extern char *strncpy(char *, char *, short int);
extern char *strcat (char *, char *);
extern char *strncat(char *, char *, short int);
extern signed char strcmp (char *, char *);
extern signed char strncmp(char *, char *, short int);
extern signed char strnicmp(char *, char *, short int);
extern char  *strchr (char *, char);
extern char  *strrchr(char *, char);
extern short int strspn (char *, char *);
extern short int strcspn(char *, char *);
extern char  *strpbrk(char *, char *);
extern char  *strstr (char *, char *);
extern short int  strlen (char  * );
extern char  *strtok (char  *, char *);
extern void  *memcpy (void  *, void  *, short int);
extern short int memcmp (void  *, void  *, short int);
extern void  *memset (void  *, unsigned char, short int);
extern void  *memmove(void  *, void  *, short int);

#endif

