/* CONIO.H, for the console and port IO for Z80
   created by G.Dar in may 1990
   (C) ADPM 1994-2001
   (C) Dario's Automation 2025 - small version/68000
   */
                                   
/* function prototypes */

#ifdef Z80
char getch(void);
unsigned char inp(unsigned char);
unsigned char outp(unsigned char, unsigned char);
char kbhit(void);
char putch(char);
char ungetch(char);
char isBreak(void);
void doComm(void);

#elif MC68000
char getch(void);
unsigned char inp(unsigned char);
unsigned char outp(unsigned char, unsigned char);
char kbhit(void);
char putch(char);
char ungetch(char);
char isBreak(void);

#else
int getch(void);
int inp(unsigned int);
int outp(unsigned int, unsigned int);
int kbhit(void);
int putch(int);
int ungetch(int);
     
char *cgets(char *);
int cprintf(char *, ...);
int cputs(char *);
int cscanf(char *, ...);
int getche(void);
unsigned inpw(unsigned int);
unsigned outpw(unsigned int, unsigned int);

#endif


